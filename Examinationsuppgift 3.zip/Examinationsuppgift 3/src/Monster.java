
public class Monster
{
  String name = "monster";
}
